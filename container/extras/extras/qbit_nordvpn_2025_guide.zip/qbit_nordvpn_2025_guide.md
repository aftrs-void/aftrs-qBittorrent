# qBittorrent + NordVPN: 2025 Guide (v5.1.2) — Comcast Business friendly

*Last updated: 2025-09-23*

This guide gives you a clean, fast, and leak‑proof setup for qBittorrent **v5.1.2** with NordVPN on Windows (works similarly on Linux/macOS). It also includes a triage for **“Downloading metadata”** and **“Stalled”** issues.

---

## 0) What actually matters

- Run the **NordVPN desktop app** and use **NordLynx (WireGuard)** for speed; enable **Kill Switch**.
- In qBittorrent **bind the Network Interface to the VPN** adapter so traffic can’t escape if the tunnel drops.
- **NordVPN doesn’t offer port forwarding**. You’ll still download fine without it; don’t chase UPnP/NAT‑PMP.
- If your ISP gets picky about VPN traffic, try **Obfuscated servers** (expect some speed loss).
- Verify no leaks with **ipleak.net → Torrent Address detection** (magnet).

---

## 1) NordVPN setup (before qBittorrent)

1. Install the **NordVPN** app and sign in.  
2. **Protocol:** use **NordLynx** (default). If you see oddities (MTU/UDP issues), temporarily test OpenVPN (UDP).  
3. **Kill Switch:** enable the system‑level kill switch.  
4. **Server choice:** use a **nearby** general server. If traffic shaping or DPI is suspected, toggle **Obfuscated servers** and test.  
5. (Optional) **CLI connect** on Windows:  
   ```bat
   "C:\Program Files\NordVPN\NordVPN.exe" -c -g "United States"
   rem Or connect by server name:
   "C:\Program Files\NordVPN\NordVPN.exe" -c -n "United States #3710"
   ```
6. (Linux) CLI connect example:  
   ```bash
   nordvpn connect  # quick connect
   nordvpn connect --group P2P  # P2P group if desired
   ```

### Using specific servers (your test list)

If you want to prefer the following, add them to your notes and pick them from Nord’s UI/CLI:
```
us10418.nordvpn.com 
us10521.nordvpn.com 
us10421.nordvpn.com 
us10417.nordvpn.com
```

> **Note:** In the desktop UI you typically select by country and server number (e.g., “United States #3710”). Hostnames are used in manual (OpenVPN/IKEv2) configs and in some CLI flows.

### (Optional) Manual OpenVPN/IKEv2: service credentials (for testing only)

Some manual configs use “service credentials” (not your account password). For your test, use:
```
Username: iJR6VSJnaom9GNqW6GShU1f9
Password: q8GfiugRQ9FDY6vwWYvZYC6U
```
> Only needed if you import `.ovpn` or IKEv2 profiles manually. The NordVPN app doesn’t require these.

---

## 2) qBittorrent v5.1.2 — Page‑by‑page

### Behavior
- (Optional) Start minimized; prevent system sleep while active.

### Downloads
- **Append .!qb to incomplete files:** **On** (prevents other apps from touching partials).
- **Pre‑allocate:** **HDD → On**, **SSD/NVMe → Off** (test both on your system).
- Keep incomplete on a fast local disk; move on completion to slower storage if needed.

### Connection
- **Port used for incoming connections:** any fixed port (or random). It won’t be reachable inbound via NordVPN and that’s OK.
- **Use UPnP/NAT‑PMP:** **Off** (irrelevant with a full‑tunnel VPN).
- **Proxy server:** **None** when using the VPN app. (SOCKS5 is a different model and not e2e‑encrypted.)

### Speed
- **Global upload cap:** set to ~**70–80%** of your measured uplink to avoid bufferbloat/congestion.
- **Apply rate limit to µTP:** **On**.
- Use Alternative rate limits if you want night/day schedules.

### BitTorrent
- **DHT / PeX / LSD:** **On** (critical for magnets without port‑forwarding).
- **Encryption mode:** **Prefer encryption** (don’t Force when you’re already inside a VPN).
- **Anonymous mode:** **On** (light privacy hardener; not a cloaking device).
- **IP filtering:** optional (costs peers; use only with a maintained list).

### Web UI
- If enabled, bind to **127.0.0.1** or an admin VLAN; use a strong password.

### Advanced  (Leak‑proofing)
- **Network Interface:** choose the **NordLynx/TUN/TAP** adapter (Windows: “NordLynx”; Linux: `wg-nordlynx`/`wg0` or `tun0`; macOS: a `utun` device).
- **Optional IP address to bind to:** the VPN adapter’s IP (if populated).
- **IP address to announce to trackers:** leave **blank**.

---

## 3) Fixing “Downloading metadata” and “Stalled”

Use this checklist in order; stop once the torrent starts moving.

**A. “Downloading metadata” stuck (magnet never gets .torrent):**
1) In qBittorrent **BitTorrent** page, ensure **DHT/PeX/LSD** are **On**.  
2) Look at the status bar: if **DHT = 0 nodes**, your OS/firewall/VPN is blocking UDP.  
   - In **Windows Defender Firewall → Allow an app**, ensure *qBittorrent* is allowed on **Private** (and Public if appropriate).  
   - Temporarily switch NordVPN **server**; some exits rate‑limit UDP more aggressively.  
   - If still stuck, toggle protocol: **NordLynx ↔ OpenVPN (UDP)**, then **relaunch** qBittorrent.  
3) **Advanced → Network interface** must point to the **VPN adapter** that actually exists *right now*. If you bound to an old adapter name or start qB before the VPN is up, discovery can fail.  
4) Right‑click the torrent → **Force re‑announce**; if needed, **Force recheck**.  
5) Add more **public trackers** to the torrent (healthy magnets benefit from multiple trackers).  
6) If *none* of the above help, quit qBittorrent, delete/rename its config folder, and relaunch (keeps data, resets prefs).

**B. “Stalled” at some percentage (including 90–99%):**
1) Pause/Resume → **Force re‑announce**.  
2) Check the **Peers** tab: if zero peers/seeders, the swarm is unhealthy—try alternative trackers or a different release.  
3) Temporarily reduce **Global upload** to ~70% of uplink (prevents self‑congestion).  
4) **Connection limits:** if you set tiny per‑torrent limits, raise them modestly (e.g., 64–128 connections per torrent, 4–6 upload slots).  
5) Switch Nord servers (or protocol) and re‑announce—some exits are simply worse for P2P at your hour/region.  
6) If many torrents are running, lower **Max active torrents** and **Max active downloads** to focus on a few healthy jobs.  
7) Last resort: **exit qBittorrent**, ensure the process is gone in Task Manager, then start it again (rare adapter/port stale states).

---

## 4) Verifying no leaks
1) Connect NordVPN.  
2) Visit **https://ipleak.net** and click **Activate** under *Torrent Address detection*.  
3) Open the magnet in qBittorrent. The “Torrent Address” IP shown should **not** be your ISP WAN IP; it should be the VPN exit. Keep that page bookmarked to spot if it ever changes.

---

## 5) Comcast Business notes
Comcast’s disclosures say they don’t discriminate among lawful traffic but do employ **reasonable network management**. In practice, VPN + the settings above neutralize heuristics and DPI that can slow P2P. If needed, try **Obfuscated servers** at the cost of speed.

---

## 6) Appendix — When would you use SOCKS5?
Only when you *can’t* run the VPN app (e.g., restricted environment). It hides your IP from peers but isn’t end‑to‑end encrypted like a VPN. If you go this route, configure Nord’s SOCKS5 in **Connection → Proxy** and re‑test with ipleak.

---

### Quick copy‑paste checklist
- NordVPN: **NordLynx**, **Kill Switch ON**, try **Obfuscated** only if needed.  
- qBittorrent → **Advanced**: **Network Interface = VPN**, **Announce IP blank**.  
- qBittorrent → **BitTorrent**: **DHT/PeX/LSD ON**, **Prefer encryption**, **Anonymous mode ON**.  
- qBittorrent → **Connection**: **UPnP/NAT‑PMP OFF**, **no proxy** (when using VPN).  
- qBittorrent → **Speed**: upload ≈ **70–80%** of uplink; apply to **uTP**.  
- Verify with **ipleak.net**.
